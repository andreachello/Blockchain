import ContactDetails from "./ContactDetails";
import * as actions from "./actions";
import reducer from "./reducer";

export default ContactDetails;
export { actions, reducer };