export const DEFAULTS = {
  CACHE: true,
  RATE_LIMIT: true,
  JWTS_REQUESTS_PER_MINUTE: 5,
}
