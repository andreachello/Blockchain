export interface JwtToken {
  scope: string[]
  permissions: string[]
}
