export class CustomerProofRequest {
  payload: string
}
