export class TransactionStatusUpdateRequest {
  transactionStatus: string
}
