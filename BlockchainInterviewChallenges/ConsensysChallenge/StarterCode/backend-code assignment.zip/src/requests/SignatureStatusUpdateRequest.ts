export class SignatureStatusUpdateRequest {
  transactionStatus: string
}
