export class SignatureRequest {
  payload: any
  accountId: string
  signatureVersion: string
}
