export class EthereumAccountWithBalance {
  id: string

  address: string

  label: string

  chainId: number

  balance: string
}
