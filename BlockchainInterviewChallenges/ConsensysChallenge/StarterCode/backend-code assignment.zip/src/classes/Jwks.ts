import { JwkPublicKey } from './JwkPublicKey'

export class JWKS {
  keys: JwkPublicKey[]
}
