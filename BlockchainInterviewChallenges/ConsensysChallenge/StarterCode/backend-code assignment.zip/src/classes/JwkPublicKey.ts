export class JwkPublicKey {
  'kty': string
  'e': string
  'use': string
  'kid': string
  'alg': string
  'n': string
}
